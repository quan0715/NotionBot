from NotionObject import *


class SearchObject(NotionObject):
    pass